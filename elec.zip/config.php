<?php

declare(strict_types=1);

return [
    'APP_NAME' => 'Ogun State Political Membership & Election Monitoring System',
    'APP_ENV' => 'local',
    'APP_DEBUG' => true,
    'APP_URL' => 'http://localhost/elec/public',

    'DB_HOST' => '127.0.0.1',
    'DB_PORT' => '3306',
    'DB_DATABASE' => 'ogun_political_test',
    'DB_USERNAME' => 'root',
    'DB_PASSWORD' => '',

    'MAIL_MAILER' => 'smtp',
    'MAIL_HOST' => 'smtp.example.com',
    'MAIL_PORT' => 587,
    'MAIL_USERNAME' => '',
    'MAIL_PASSWORD' => '',
    'MAIL_ENCRYPTION' => 'tls',
    'MAIL_FROM_ADDRESS' => 'no-reply@example.com',
    'MAIL_FROM_NAME' => 'Ogun Political System',

    'SESSION_NAME' => 'ogun_session',
    'UPLOAD_MAX_KB' => 100,
    'DEFAULT_STATE' => 'Ogun State',
    'DEFAULT_COUNTRY' => 'Nigeria',
];
