<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Support\Auth;
use App\Support\Request;

final class SettingsController extends Controller
{
    public function index(Request $request): void
    {
        Auth::requiresRole('super-admin');
        $this->view('settings/index', ['title' => 'Settings']);
    }
}
